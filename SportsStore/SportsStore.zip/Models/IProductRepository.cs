﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsStore.Models
{
    public interface IProductRepository
    {
        public IQueryable<Product> GetAllProducts();

        //collection of products pulled out of a database
        //returns collection of products
    }
}
